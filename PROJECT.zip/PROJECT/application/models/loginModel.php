

<?php

 class loginModel extends CI_Model{

       public function isvalidate($username,$password)
       {
        
        $q = $this->db->where(['username' => $username,'password'=>$password])
                      ->get('users');
                           
    // select * from users where username = $username and password = $password;
        
                      if($q->num_rows())
                      {
                        
                        return  $q->row()->id;
                      }
                      else{
                        return false;
                      }
       }


       public function articleList($limit,$offset)
{
    $id = $this->session->userdata('id');
    $q = $this->db->select('')
        ->from('articles')
        ->where(['user_id' => $id])
        ->limit($limit,$offset)
        ->get();


        //result_array hme multiple objects return krta h array form me
      return $q->result_array();
      
}

     public function add_article($array)
     {

         return  $this->db->insert('articles' , $array);
     }

     public function registerUser($array)
     {
      return  $this->db->insert('users' , $array);
     }


     public function del($id)
     { 
          return  $this->db->delete('articles' ,['id'=>$id]);
     }

     public function getArticleCount()
     {
         $id = $this->session->userdata('id');
         $q = $this->db->select('')
             ->from('articles')
             ->where(['user_id' => $id])
             ->get();
     
         return $q->num_rows();
     }



     public function findArticle($articleid)
     {
         $q =  $this->db->select(['article_title','article_body','id'])
                  ->where('id' ,$articleid)
                 ->get('articles');

                 //yha 1 hi row milni h bs isliye row use kr rhe h result nhi array to return krega mgr only 1 row
                 //resuly use krne se array mil rhe index dekr pr hme only one row chaiue thats why we are using row;
                 return $q->row();
     }


     public function updateArticle($articleid ,Array $article)
     {
       return  $this->db->where('id',$articleid)
                  ->update('articles' ,$article);
     }
 

 }

?>