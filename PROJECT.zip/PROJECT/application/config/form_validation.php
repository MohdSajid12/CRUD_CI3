<?php   

   $config = [


   'add_article_rules' => [
                      [
                        'field' => 'article_title',
                        'title'=> 'Article_Title',
                        'rules' => 'required'
                      ],
                      [
                        'field' => 'article_body',
                        'title'=> 'Article_Body',
                        'rules' => 'required'
                      ]
                      ],

                      'register_user' =>[

                        [
                          'field' => 'username',
                          'title'=> 'username',
                          'rules' => 'required'
                        ],
                        [
                          'field' => 'password',
                          'title'=> 'password',
                          'rules' => 'required'
                        ],
                        [
                          'field' => 'firstname',
                          'title'=> 'firstName',
                          'rules' => 'required'
                        ],
                        [
                          'field' => 'lastname',
                          'title'=> 'lastName',
                          'rules' => 'required'
                        ]
                      ] 

                    ]
                    
?>