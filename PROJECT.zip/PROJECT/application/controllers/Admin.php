<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function index()
    {    

        $this->load->library('form_validation');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required|alpha');
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

        if ($this->form_validation->run()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $login_id = $this->loginModel->isvalidate($username, $password);

            if ($login_id) {
                $this->session->set_userdata('id',$login_id);
                $this->session->set_flashdata('message', 'logged in successfully');
                return redirect('Admin/welcome');
            } else {
                $this->session->set_flashdata('message', 'Incorrect username or password');
                redirect('admin/login');
            }
        } else {
            $this->load->view('Admin/login');
        }
    }

    public function welcome()
     {

        $config = [
            'base_url'=> base_url('admin/welcome'),
            'per_page'=> 2,
            'total_rows'=> $this->loginModel->getArticleCount(),
        ];

        $this->pagination->initialize($config);

    
        if (!$this->session->userdata('id')) {
                     return redirect('Admin');
             }
   
        $this->load->model('loginModel');
        $articles = $this->loginModel->articleList($config['per_page'],$this->uri->segment(3));

        $this->load->view('Admin/dashboard', ['articles' => $articles]);
    }

    public function logout()
    {
        $this->session->unset_userdata('id');
        $this->session->set_flashdata('message', 'Logged out sccessfully');
       return redirect('Admin');
    }
    
    public function addUser()
    {
        $this->load->view('admin/addArticle');
    }


    public function userValidation()
    {

        $this->load->library('form_validation');
        if($this->form_validation->run('add_article_rules')){
             
            $post = $this->input->post();

    

            $return =   $this->loginModel->add_article($post);

            if($return)
            {
                $this->session->set_flashdata('message', 'Inserted Successfully');
                redirect('admin/welcome');
            }
            else
            {
                $this->session->set_flashdata('message', 'please try again');
            }
        }
        else{
            $this->load->view('admin/addArticle');
        }
    }

    public function register()
    {
        $this->load->view('Admin/register');
  
    }

    public function login()
    {
        $this->load->view('Admin/login');
       
    }

    public function registerUser()
    {
        $this->load->library('form_validation');
        if ($this->form_validation->run('register_user')) {
               
            $post  =  $this->input->post();

           $return =      $this->loginModel->registerUser($post);

           if($return){
            $this->session->set_flashdata('message', 'Registered Succssfully');
            redirect('admin/login');
           }
           else
           {
            echo "something went wrong";
           }




        } else {
            $this->load->view('Admin/register');
        }
    }


    public function delArticle()
    {
       $id = $this->input->post('id');

          $myreturn = $this->loginModel->del($id);


          if($myreturn)
          {
            echo "delete successfull";
          }
          else
          {
            echo "something went wrong";
          }

    }

   
    public function editUser()

    {
        $id = $this->input->post('id');

         $rt = $this->loginModel->findArticle($id);

         $this->load->view('Admin/editArticle',['article' =>$rt]);
        
    }



    public function updateArticle()
{
    $articleid = $this->input->post('article_id');
    
    $article = array(
        'article_title' => $this->input->post('article_title'),
        'article_body' => $this->input->post('article_body')
    );

    $return = $this->loginModel->updateArticle($articleid, $article);

    if ($return) {
        $this->session->set_flashdata('message', 'Updated Successfully');
        redirect('admin/welcome');
    } else {
        $this->session->set_flashdata('message', 'Failed to update');
        redirect('admin/welcome');
    }
}

}
