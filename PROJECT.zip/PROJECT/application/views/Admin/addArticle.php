<?php include('header.php')  ?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  </head>

  <style>
    #button{
      width :700px;
    }
  </style>
  <body>

   
<div class="container mx-auto p-4">
<h1>Add Articles</h1><br>


<?php  echo form_open_multipart('admin/userValidation','','')?>
<?php echo form_hidden('user_id', $this->session->userdata('id')); ?>



  <div class="mb-3" style="width: 700px;">
    <label for="" class="form-label">Article_Title</label>
    <input type="text" class="form-control" name="article_title" value="<?php echo set_value('article_title')  ?>" placeholder="Enter Article_Title">
    <?php echo form_error('article_title') ?>
  </div>
  

  <div class="mb-3" style="width: 700px;">
    <label for="" class="form-label">Article_Body</label>
    <input type="textarea" class="form-control"  name="article_body"
    value="<?php echo set_value('article_body') ?>"  placeholder="Enter Article_Body">
    <?php echo form_error('article_body') ?>

  </div>

  
  <button type="submit" class="btn btn-primary btn-lg" id="button">Submit</button><br><br>

  
  <button type="reset" class="btn btn-danger  btn-lg" id="button">Reset</button><br><br>


 
  <?php echo form_close()?>
            </div>
        </div>
     </div>
     </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
  </body>
</html>