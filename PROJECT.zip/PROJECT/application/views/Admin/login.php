<?php include('header.php')  ?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  </head>

  <style>
    #button{
      width :700px;
    }
  </style>
  <body>

  <?php if($this->session->flashdata('message')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <?php echo $this->session->flashdata('message'); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>
   
<div class="container mx-auto p-4">
<h1>Admin Form</h1><br>

<?php  echo form_open_multipart('Admin/index','','')?>



  <div class="mb-3" style="width: 700px;">
    <label for="exampleInputEmail" class="form-label">Username</label>
    <input type="text" class="form-control" id="exampleInputEmail" name="username" value="<?php echo set_value('username')  ?>" placeholder="Enter Username">
    <?php echo form_error('username') ?>
  </div>
  


  <div class="mb-3" style="width: 700px;">
    <label for="exampleInputPassword" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword" name="password"
    value="<?php echo set_value('password') ?>"  placeholder="Enter Password">
    <?php echo form_error('password') ?>

  </div>

  
  <button type="submit" class="btn btn-primary btn-lg" id="button">Login</button><br><br>

  
  <button type="reset" class="btn btn-danger  btn-lg" id="button">Reset</button><br><br>

  Dont have an account Sigup?<br>
  <a href=<?php echo site_url('Admin/register')?> class="btn btn-primary btn-lg" tabindex="-1" role="button" aria-disabled="true">Signup</a>
 
  <?php echo form_close()?>
            </div>
        </div>
     </div>
     </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
  </body>
</html>