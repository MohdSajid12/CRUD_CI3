<?php include('header.php')  ?>



<?php if($this->session->flashdata('message')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <?php echo $this->session->flashdata('message'); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>


<div class="container">

    <a href="<?php echo base_url('admin/addUser') ?>" class="btn btn-primary" style="margin-top: 40px;">Add Articles</a </div>
    
    
    <span class="pagination">
        <?php echo $this->pagination->create_links(); ?>
    
    </span>
    <div class="container" style="margin-top:25px;">
        
    <!-- <?php  echo $this->db->last_query(); ?> -->
    <div class="table">
        <table>
                <thead>
                    <tr>
                        <th>Article-Title</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($articles)) : ?>
                        <?php foreach ($articles as $art) : ?>
                            <tr>
                                <td><?php echo $art['article_title']; ?></td>
                                <td> <?php 
    echo form_open('Admin/editUser');
    echo form_hidden('id', $art['id']);
    echo form_submit(['name'=>'submit','value'=>'Edit' ,'class'=>'btn btn-success']);
    echo form_close();
?></td>
                                <td>
                                <?php 
    echo form_open('Admin/delArticle');
    echo form_hidden('id', $art['id']);
    echo form_submit(['name'=>'submit','value'=>'Delete' ,'class'=>'btn btn-danger']);
    echo form_close();
?>

                                </td>

                            </tr>

                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>

            
 
            </table>
        </div>

    </div>