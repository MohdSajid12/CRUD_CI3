<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  </head>

  <style>
    p{
      color:red;
    }
  </style>
  <body>


   
<div class="container mx-auto p-4">

<h2>Registration Form</h2>
<?php  echo form_open_multipart('Admin/registerUser','','')?>

  <div class="mb-3" style="width: 700px;">
    <label for="exampleInputFirstName" class="form-label">Username</label>
    <input type="text" class="form-control" id="exampleInputFirstName" aria-describedby="emailHelp"  name="username"  value="<?php echo set_value('username') ?>">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    <?php echo form_error('username') ?>
  </div>



  <div class="mb-3" style="width: 700px;">
    <label for="exampleInputPassword" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword" name="password"
    value="<?php echo set_value('password') ?>">
    <p><?php echo form_error('password') ?></p>

  </div>
  
  <div class="mb-3" style="width: 700px;">
    <label for="" class="form-label" >First-Name</label>
    <input type="text" class="form-control" id="" name="firstname"  value="<?php echo set_value('firstname') ?>">
    <p><?php echo form_error('firstname') ?></p>
  </div>

  <div class="mb-3" style="width: 700px;">
    <label for="" class="form-label"> Last-Name</label>
    <input type="text" class="form-control" id="" name="lastname"  value="<?php echo set_value('lastname') ?>">
    <p><?php echo form_error('lastname') ?></p>
  </div>

  
  
  <button type="submit" class="btn btn-primary btn-lg">Submit</button><br><br>


  Have an account? <br>
  <a href="login" class="btn btn-primary btn-lg" tabindex="-1" role="button" aria-disabled="true">Login</a>

  <?php echo form_close()?>
            </div>
        </div>
     </div>
     </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
  </body>
</html>
